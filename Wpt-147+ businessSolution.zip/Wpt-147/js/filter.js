/**
 * Created by tikhonov3 on 13.03.2017.
 */
const data = [
    {
        title: "", img: "", description: "", linkInfo: "#", linkBuy: "", filter: {
        Virtualization: true,
        Partitioning: true,
        Backup: true,
        Migration: true,
        Restore: true,
        Maintenance: true,
        Bundles: true,
        Optimization: true,
        Security: true,
        OS: true,
        interopterability: true,
        Windows: true,
        OSX: true,
        Linux: true,
        Freeware: true
    }
    },
    {
        title: "", img: "", description: "", linkInfo: "#", linkBuy: "", filter: {
        Virtualization: true,
        Partitioning: true,
        Backup: true,
        Migration: true,
        Restore: true,
        Maintenance: true,
        Bundles: true,
        Optimization: true,
        Security: true,
        OS: true,
        interopterability: true,
        Windows: true,
        OSX: true,
        Linux: true,
        Freeware: true
    }
    },
    {
        title: "", img: "", description: "", linkInfo: "#", linkBuy: "", filter: {
        Virtualization: true,
        Partitioning: true,
        Backup: true,
        Migration: true,
        Restore: true,
        Maintenance: true,
        Bundles: true,
        Optimization: true,
        Security: true,
        OS: true,
        interopterability: true,
        Windows: true,
        OSX: true,
        Linux: true,
        Freeware: true
    }
    }


];
